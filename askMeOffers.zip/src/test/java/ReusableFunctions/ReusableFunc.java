package ReusableFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Repository.ObjectRepositories;

public class ReusableFunc extends ObjectRepositories {
//	 static By homeLink = By.xpath(HOMEPAGE_HOME_LINK_XPATH);
//	static By searchTab = By.xpath(HOMEPAGE_SEARCH_XPATH);
//	public static  WebDriver driver;
//	public  static void SearchingEcomWebsite() {
//		driver.findElement(homeLink).click();
//		WebElement ele =    driver.findElement(searchTab);
//	         ele.click();
	}

