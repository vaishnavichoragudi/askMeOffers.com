package AskMeOffers.com.Project;




import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Repository.ObjectRepositories;
import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * Unit test for simple App.
 */

public class AppTest extends ObjectRepositories
{
By askMeOfferHeader = By.xpath(HOMEPAGE_ASKMEOFFERS_HEARDERS_XPATH);
 By homeLink = By.xpath(HOMEPAGE_HOME_LINK_XPATH);
By searchTab = By.xpath(HOMEPAGE_SEARCH_XPATH);
By searchForStoreCoupons = By.id(HOMEPAGE_SEARCHFORSTORESCOUPONS_ID);
By searchecomm = By.xpath(HOMEPAGE_SEARCH_FOR_ECOM_WEBSITES_XPATH);
By iconSelection = By.xpath(HOMEPAGE_ICON_SELECTION_XPATH);
By contentSelection = By.xpath(HOMEPAGE_TABLE_CONTENTS_XPATH);
By tableContent = By.xpath(HOMEPAGE_TABLE_CONTENTS_XPATH);
By selectingCouponsLink = By.xpath(HOMEPAGE_COUPONS_XPATH);
By allCouponCount = By.xpath(HOMEPAGE_ALL_COUPON_COUNT_XPATH);
By dealsCount = By.xpath(HOMEPAGE_DEALS_COUPON_COUNT_XPATH);
By redeemCouponsTab = By.xpath(HOMEPAGE_REDEEM_COUPONS_XPATH);
By firstRedeemCoupon = By.xpath(HOMEPAGE_FIRST_REDEEM_COUPON_XPATH);
By copyCode = By.xpath(HOMEPAGE_COPYCODE_XPATH);
By copyCodeSuccessMsg = By.xpath(HOMEPAGE_COUPONCODE_SUCCESFUL_MSG_XPATH);
By noIconsAreDisplayed = By.xpath(HOMEPAGE_NOICONSDISPLAYED_INVALIDCODE_XPATH);
By ecommerceWebsiteList = By.xpath(HOMEPAGE_ECOMMERCENAMES_XPATH);




	public static  WebDriver driver;
	public static Properties p;
	public static FileInputStream fis;
	
	@BeforeMethod
	public void driverLaunch() throws Exception {
		 // reading data from data.properties 
	
		 fis = new FileInputStream("./data.properties");
		  p = new Properties();
		  p.load(fis);
		
		// Launching driver 
		if(p.getProperty("Browser").equalsIgnoreCase("chrome")) {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		 driver.manage().window().maximize();
		}
		//Launching url
		  driver.get(p.getProperty("url"));
		 String title = driver.getTitle(); 
		 if(title.contains("Thank you for Installing")) {
			System.out.println("Succesfully Installed");
		 }
		
	}
    
	@Test
    //TC_001 - Verifying whether 'All coupons' count is sum of 'coupons' and 'deals' count (positive flow)
public  void zomatoFlow()     {
		SearchingEcomWebsite();
		driver.findElement(searchForStoreCoupons).sendKeys(p.getProperty("search"));
        driver.findElement(iconSelection).click();
		
			 List<WebElement> elements = driver.findElements(contentSelection); 
	 for(WebElement s : elements) { 
			 if(s.getText().contains(p.getProperty("tableContent"))) {
			 s.click(); 
				 } 
			 }
			 String ActNoOfCoupons = driver.findElement(selectingCouponsLink).getText(); 
			 String AllCount = driver.findElement(allCouponCount).getText();
			 String DealsCount = driver.findElement(dealsCount).getText();
			 if(AllCount == ActNoOfCoupons + DealsCount) {
			  System.out.println("Succesfully verified");
			  }   
    }
	
	@Test 
	// TC_002 - searching with invalid coupon id in search tab in homepage (Negetive scenario)
	public void searchWithCoupoun() {
		
		SearchingEcomWebsite();
		driver.findElement(searchForStoreCoupons).sendKeys(p.getProperty("coupon"));
		// verify no e-commerce links are displayed
		Boolean iconDisplayed = driver.findElement(noIconsAreDisplayed).isDisplayed();
		if(!iconDisplayed == false) {
			System.out.println("No e-commerece icons are displayed due to Invalid Coupon code");
		}

		
	
    }
	
	
	
	@Test 
	// TC_003 - verifying whether the driver is navigating to exact url after clicking on 'redbus' icon to redeem coupons (Positive flow)
	public  void redBusFlow() {
		
		SearchingEcomWebsite();
	driver.findElement(searchForStoreCoupons).sendKeys(p.getProperty("search1"));
		 driver.findElement(iconSelection).click();
		String s = driver.getCurrentUrl();
		if(s.contains("redbus-coupons")) {
			System.out.println("driver has succesfully navigated to the redbus page");
		
		
	}
}
		
		@Test 
		// TC_004 -  clicking on redeem coupon on Flipkart page and verifying whether is landed to the targeted page (positive flow)
		public void flipKartRedeemCoupon() {
			SearchingEcomWebsite();
		driver.findElement(searchForStoreCoupons).sendKeys(p.getProperty("search2"));
			 driver.findElement(iconSelection).click();
			 driver.findElement(firstRedeemCoupon).click();
			 
			 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 //clicking on copy code 
//			 driver.findElement(copyCode).click();
//		 String urll = driver.getCurrentUrl();
//			 if(urll.contains("flipkart")) {
//				 System.out.println("succesfully copying the coupon and navigating to Flipkart website");
			
	}
		
	
   
	 @Test 
	 // TC_005 - getting all e-commerce website names which are present by just clicking on 'Home' link
	 public void EcommerceWebsites() {
		   
			driver.findElement(homeLink).click();
			WebElement ele =    driver.findElement(searchTab);
		         ele.click();
		      List<WebElement> website =  driver.findElements(ecommerceWebsiteList);
		       for(WebElement Ecom : website) {
		    	   System.out.println(Ecom.getText());
		    	   
		       }
		         
		
		
	}

    
    @AfterMethod
    public void tearDown() {
 driver.close();
    }
   
    public  void SearchingEcomWebsite() {
		driver.findElement(homeLink).click();
		WebElement ele =    driver.findElement(searchTab);
	         ele.click();
	}

}
