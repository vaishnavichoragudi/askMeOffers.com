package Repository;

public class ObjectRepositories {
	// Homepage locators
public static final String HOMEPAGE_ASKMEOFFERS_HEARDERS_XPATH = "//a[text()='askmeoffers.com']";
public static final String HOMEPAGE_SEARCHICON_XPATH = "//span[@class='search-icon']";
public static final String HOMEPAGE_SEARCHFORSTORESCOUPONS_ID = "my-input-inside";

//Icons in Homepage
public static final String HOMEPAGE_NOICONSDISPLAYED_INVALIDCODE_XPATH = "//div[@role='list']";
public static final String HOMEPAGE_ECOMMERCENAMES_XPATH = "//div[@role='list']/a";

//links on Homepage
public static final String HOMEPAGE_HOME_LINK_XPATH = "(//a[text()='Home'])[2]";
public static final String HOMEPAGE_SEARCH_XPATH = "//*[@id='headserpp']";
public static final String HOMEPAGE_SEARCH_FOR_ECOM_WEBSITES_XPATH = "//input[@id='my-input-inside']";
public static final String HOMEPAGE_INVALID_SEARCH_XPATH= "//p[text()='What do you want to search today?']";
public static final String HOMEPAGE_ICON_SELECTION_XPATH = "//div[@role='list']//a";
public static final String HOMEPAGE_TABLE_CONTENTS_XPATH = "//*[@class='table-index store-desc tocdesktop']//a";
public static final String HOMEPAGE_COUPONS_XPATH = "//a[@title='Coupons Only']/span";
public static final String HOMEPAGE_ALL_COUPON_COUNT_XPATH = "//a[contains(text(),'All ')]/span";
public static final String HOMEPAGE_DEALS_COUPON_COUNT_XPATH = "//a[contains(text(),'Deals ')]/span";
public static final String HOMEPAGE_REDEEM_COUPONS_XPATH = "//span[contains(text(),'Redeem')]";
public static final String HOMEPAGE_FIRST_REDEEM_COUPON_XPATH = "(//span[contains(text(),'Redeem')])[1]";
public static final String HOMEPAGE_COPYCODE_XPATH = "//span[contains(text(),'Copy Code')]";
public static final String HOMEPAGE_COUPONCODE_SUCCESFUL_MSG_XPATH = "//*[text()='Success! Coupon code has been activated.']";


}
